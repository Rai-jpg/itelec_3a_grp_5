<script>
    document.querySelectorAll('#menu li').forEach(item => {
        item.addEventListener('click', () => {
            const menuItemText = item.querySelector('span').textContent;
            alert(`You clicked on ${menuItemText}`);
            // Here you can add more actions like navigating to different pages, etc.
        });
    });
</script>

const projects = [
    { id: 1, name: "Feeding Program", location: "Marawoy Elementary School", date: "October 21, 2024" },
    { id: 2, name: "Tree planting", location: "Marawoy", date: "October 24, 2024" },
    { id: 3, name: "Beach Cleanup", location: "Marawoy Beach", date: "November 1, 2024" }
];