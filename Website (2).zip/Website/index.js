<script>
const projects = [
    { id: 1, name: "Feeding Program", location: "Marawoy Elementary School", date: "October 21, 2024" },
    { id: 2, name: "Tree planting", location: "Marawoy", date: "October 24, 2024" },
    { id: 3, name: "Beach Cleanup", location: "Marawoy Beach", date: "November 1, 2024" }
];

document.querySelectorAll('#menu li').forEach(item => {
    item.addEventListener('click', () => {
        const menuItemText = item.querySelector('span').textContent;

        if (menuItemText === "My Projects") {
            displayProjects();
        } else {
            alert(`You clicked on ${menuItemText}`);
        }
    });
});

function displayProjects() {
    const projectTable = document.getElementById('project-table');
    // Clear previous project entries, but keep the header
    projectTable.innerHTML = `
        <tr>
            <th>Project</th>
            <th>Location</th>
            <th>Date</th>
            <th>Option</th>
        </tr>
    `;

    projects.forEach(project => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${project.name}</td>
            <td>${project.location}</td>
            <td>${project.date}</td>
            <td><button class="btn">Join</button></td>
        `;
        projectTable.appendChild(row);
    });
}
</script>
</body>
</html>