<?php
// Database connection
$servername = "localhost"; // your server name
$username = "your_username"; // your database username
$password = "your_password"; // your database password
$dbname = "your_database_name"; // your database name

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die(json_encode(["success" => false, "message" => "Connection failed: " . $conn->connect_error]));
}

// Handle form submission
$data = json_decode(file_get_contents("php://input"), true);
$userID = $data['userID'];
$password = $data['password'];

// Prepare SQL statement to prevent SQL injection
$stmt = $conn->prepare("SELECT * FROM usertbl WHERE userID = ?");
$stmt->bind_param("i", $userID);
$stmt->execute();
$result = $stmt->get_result();

// Check if user exists
if ($result->num_rows > 0) {
    $user = $result->fetch_assoc();
    // Verify password (consider using password_hash and password_verify for better security)
    if ($password === $user['password']) {
        session_start();
        $_SESSION['userID'] = $user['userID']; // Store user ID in session
        echo json_encode(["success" => true]);
    } else {
        echo json_encode(["success" => false, "message" => "Invalid password."]);
    }
} else {
    echo json_encode(["success" => false, "message" => "No user found with that User ID."]);
}

$stmt->close();
$conn->close();
?>
